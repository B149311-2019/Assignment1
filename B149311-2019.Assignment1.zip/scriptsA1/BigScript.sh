rm -r /localdisk/home/s1988593/Assignment1
#to erase any old Assignment1 and create a new one to work with

#Ask for the directory that will be used and the name
echo -n "Directory you want to copy to work with: "
   read Assignment1
cp -r $Assignment1 ~
echo -n "directory name: "
	read name
cd ~/$name
#Ask for all the directories requiered for the script

echo -n "new directory genome for bowtie2(with "/" at the end): "
 read dirbowgenome

echo -n "name of your genome for bowtie2: "
 read bowgenome

echo -n "new genome directory and name in bed format: " 
 read bedgenome

echo -n "what is your new directory for the fq.gz files (sequences)?: "
read sequences

cd ~
##########################################################################################
#prepare genome index for bowtie2, It is done first to have it ready for the bowtie2 part
#this will first gunzip the file and then convert it to the Genome index
##########################################################################################
cd $dirbowgenome
gunzip $bowgenome

IFS='.'
read d1 d2 d3 <<< "$bowgenome"

bowtie2-build "$dirbowgenome$d1.$d2" Genome
unset IFS
cd ~

#make an array of all the fq.gz files to gunzip them, this can be done with whatever number of files there are.
cd ..
declare -a fqgz=()
fqgz=$(find $sequences -name '*.fq.gz')

for i in "${!fqgz[@]}"; do
gunzip ${fqgz[i]}
done
###########################################################
#make an array of the .fq files and do analysis with fastqc
###########################################################
declare -a fq=()
fq=$(find $sequences -name '*.fq')
echo -e "$fq"

for i in "${!fq[@]}"; do 
fastqc ${fq[i]}
done

#ask if want to show the results of analysis or continue without looking at the analysis
 echo -n "want to open analysis(Yes=1 or No=2)?"
read answer

 declare -a fa=()
        fa=$(find $sequences -name '*.html')

if test $answer == 1
         #To open fasqc analysis in firefox
        then
        for i in "${!fa[@]}"; do
        echo "Displaying analysis in firfefox, script still running"
        firefox ${fa[i]} &
        done
else
echo "no display of fastqc analysis"
fi

cd ..
#############################################################################################
#take the sequences to analyze them in bowtie2, convert to bam with samtools, and do bedtools
#############################################################################################
cd $sequences

while read num type faq1 faq2
	do
	unset IFS
	IFS=$'.'
	read a1 a2 a3 <<< "$faq1"
	read b1 b2 b3 <<< "$faq2"
	 echo "doing bowtie2 for $a1"
	bowtie2 -x $dirbowgenome/Genome -p 60 -1 $sequences$a1.$a2 -2 $sequences$b1.$b2 -S try$a1.sam
	echo "doing samtools for $a1"
 samtools view -@ 40 -S -b try$a1.sam > $num.bam
  unset IFS
  echo "doing bedtools"
  bedtools coverage -a $bedgenome -b $num.bam >> $num.txt
done < fqfiles 

#convert fqfiles to newfiles to make it easier to read by the script
awk '{print $1,$2,$3;$4;}' fqfiles > newfiles

#creating *_all.txt
touch Slender_all.txt
touch Stumpy_all.txt
##########################################################################
#Filtering output files from bedtools to see only the gene name and counts
##########################################################################
while read num type faq1 
	do
	if test $type == "Slender"
   then 
    awk '{FS="\t";OFS="\t";{print $4,$7;}}' $num.txt > $num.Slender.txt 
    else
     awk '{FS="\t";OFS="\t";{print $4,$7;}}' $num.txt > $num.Stumpy.txt 
   fi
  
done < newfiles 
unset IFS
paste *.Slender.txt >> Slender_all.txt
paste *.Stumpy.txt >> Stumpy_all.txt

awk '{FS="\t";OFS="\t";{print $1;}}' Slender_all.txt > names.txt 
#############################################################################
#this makes the averages, one for all stumply files and one for slender files
############################################################################# 
awk '{a[FNR]+=$2}END{for(i=1;i<=FNR;i++)print a[i]/(ARGC-1);}' *.Slender.txt >> Statistics_genes.txt 
awk '{a[FNR]+=$2}END{for(i=1;i<=FNR;i++)print a[i]/(ARGC-1);}' *.Stumpy.txt >> Statistics_genesS.txt 

#########################################################################################
#this paste together all the statistics in one file and displays the first 10 to the user
#########################################################################################
paste names.txt Statistics_genes.txt Statistics_genesS.txt >> Statistics.txt
echo "Gene name, average of slender samples and average of stumpy samples"
cat Statistics.txt | head -10
echo "Done"
##############
#End of script
##############