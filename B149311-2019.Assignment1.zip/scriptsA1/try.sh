cd /localdisk/home/s1988593/Assignment1/fastq/


awk '{FS="\t";OFS="\t";{print $1;}}' Slender_all.txt > result1.txt 
awk '{a[FNR]+=$2}END{for(i=1;i<=FNR;i++)print a[i]/(ARGC-1);}' *.Slender.txt >> result2.txt 
awk '{a[FNR]+=$2}END{for(i=1;i<=FNR;i++)print a[i]/(ARGC-1);}' *.Stumpy.txt >> result3.txt 

paste result1.txt result2.txt result3.txt >> result.txt
cat result.txt | head -10

