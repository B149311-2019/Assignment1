cd ~
sequences=/localdisk/home/s1988593/Assignment1/fastq/
cd $sequences

declare -a sam=()
sam=$(find . -name '*.sam')

for i in "${!sam[@]}" ;
	do 
	echo "running samtools"
	IFS=$'.'
	read s1 s2 <<< "${sam[i]}"
	echo $s1
	echo $s2
	samtools view -@ 40 -S -b $s1.$s2 > $s1.bam
	unset IFS
done

cd ~/$name

declare -a bam=()
bam=$(find $sequences -name '*.bam')

for i in "${!bam[@]}"; do
	do
	echo "running bedtools"
	IFS=$'.'
	read b1 b2 <<< "${bam[i]}"
bedtools pairtobed -abam ${bam[i]} -b $bedgenome -bedpe | head -20  >> bed_$b1.details
done

