cd ..

echo $name
echo $sequences
echo $bowgenome
echo $dirbowgenome

#take the sequences to analyze them in bowtie2
cd $sequences

while read num type faq1 faq2
	do
	unset IFS
	IFS=$'.'
	read a1 a2 a3 <<< "$faq1"
	read b1 b2 b3 <<< "$faq2"
	 echo "doing bowtie2"
	bowtie2 -x ~/$name/Genome -p 60 -1 $sequences$a1.$a2 -2 $sequences$b1.$b2 -S try$a1.sam
	unset IFS
	echo -e "try$a1.sam" >> sam.details 
done < fqfiles 

echo "finish bowtie2"

export name
export sequences
export bowgenome
export bedgenome
export dirbowgenome
