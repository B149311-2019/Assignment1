rm -r /localdisk/home/s1988593/Assignment1
#to erase any old Assignment1 and create a new one to work with

echo -n "Directory you want to copy to work with: "
   read Assignment1
cp -r $Assignment1 ~
echo -n "directory name: "
	read name
cd ~/$name
#Ask for all the directories requiered for the scripts

echo -n "new directory genome for bowtie2(with "/" at the end): "
 read dirbowgenome

echo -n "name of your genome for bowtie2: "
 read bowgenome

echo -n "new genome directory and name in bed format: " 
 read bedgenome


echo -n "what is your new directory for the fq.gz files (sequences)?: "
read sequences

cd ~

#prepare genome index for bowtie2
cd $dirbowgenome
gunzip $bowgenome

IFS='.'
read d1 d2 d3 <<< "$bowgenome"

bowtie2-build "$dirbowgenome$d1.$d2" Genome
unset IFS
cd ~


export name
export sequences
export bowgenome
export bedgenome
export dirbowgenome


