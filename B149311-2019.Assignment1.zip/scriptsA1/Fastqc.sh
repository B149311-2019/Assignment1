cd ..
declare -a fqgz=()
fqgz=$(find $sequences -name '*.fq.gz')

for i in "${!fqgz[@]}"; do
gunzip ${fqgz[i]}
done
#For Gunzip fq.gz files

declare -a fq=()
fq=$(find $sequences -name '*.fq')
echo -e "$fq"

for i in "${!fq[@]}"; do 
fastqc ${fq[i]}
done
#To do analysis on .fq files

 echo -n "want to open analysis(Y=1 or N=2)?"
read answer
#ask if want to show the results of analysis or continue with the processing
echo $answer
 declare -a fa=()
        fa=$(find $sequences -name '*.html')

if test $answer == 1
        then
        for i in "${!fa[@]}"; do
        firefox ${fa[i]} &
        #To open fasqc analysis in firefox
        done
else
echo "no display of fastqc analysis"
fi


export name
export sequences
export bowgenome
export bedgenome
export dirbowgenome